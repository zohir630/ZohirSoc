package com.synapse.social.studioasinc.shared.data.repository

import com.synapse.social.studioasinc.shared.data.crypto.SignalProtocolManager
import com.synapse.social.studioasinc.shared.data.crypto.models.EncryptedMessage
import com.synapse.social.studioasinc.shared.data.crypto.models.PreKeyBundle
import com.synapse.social.studioasinc.shared.data.datasource.SupabaseChatDataSource
import com.synapse.social.studioasinc.shared.data.dto.chat.MessageDto
import com.synapse.social.studioasinc.shared.data.local.database.CachedMessageDao
import com.synapse.social.studioasinc.shared.domain.util.EncryptedPayloadDetector
import com.synapse.social.studioasinc.shared.util.Logger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonPrimitive

/**
 * Helper class that centralizes End-to-End Encryption (E2EE) logic for chat messages.
 * It manages the lifecycle of Signal Protocol sessions, message decryption with caching,
 * and identity key initialization/synchronization with the remote server.
 *
 * This helper is intended to be used within the repository layer to ensure that
 * encryption details remain isolated from the domain and UI layers.
 */
internal class ChatEncryptionHelper(
    private val signalProtocolManager: SignalProtocolManager?,
    private val dataSource: SupabaseChatDataSource,
    private val cachedMessageDao: CachedMessageDao?
) {

    /**
     * In-memory cache for decrypted content to avoid re-decryption failures.
     * This is critical for Signal Protocol's Double Ratchet and Pre-Key messages,
     * where certain messages (like those consuming a one-time pre-key) can only
     * be decrypted once by the protocol's state machine.
     */
    private val decryptedMessageCache = mutableMapOf<String, String>()
    private val decryptionMutexes = mutableMapOf<String, Mutex>()
    private val cacheLock = Mutex()

    suspend fun cacheDecrypted(messageId: String, content: String) {
        if (messageId.isBlank()) return
        cacheLock.withLock { decryptedMessageCache[messageId] = content }
    }

    private suspend fun decryptedOrNull(messageId: String): String? =
        cacheLock.withLock { decryptedMessageCache[messageId] }

    private suspend fun mutexFor(senderId: String): Mutex = cacheLock.withLock {
        decryptionMutexes.getOrPut(senderId.ifBlank { "__global__" }) { Mutex() }
    }

    fun isPlaceholder(content: String): Boolean = EncryptedPayloadDetector.isPlaceholder(content)

    /**
     * Extracts content, mediaUrl, and metadata from a decrypted JSON payload like {"content":"...","mediaUrl":"...","metadata":"..."}.
     */
    private fun extractContent(jsonString: String): Triple<String, String?, String?> {
        return try {
            val jsonPayload = Json.parseToJsonElement(jsonString).jsonObject
            val content = jsonPayload["content"]?.jsonPrimitive?.contentOrNull ?: jsonString
            val mediaUrl = jsonPayload["mediaUrl"]?.jsonPrimitive?.contentOrNull
            val metadata = jsonPayload["metadata"]?.jsonPrimitive?.contentOrNull
            Triple(content, mediaUrl, metadata)
        } catch (_: Exception) {
            Triple(jsonString, null, null)
        }
    }

    /**
     * Attempts to decrypt a [MessageDto] if it contains encrypted content.
     *
     * The method follows a multi-tier decryption strategy:
     * 1. Check in-memory cache for immediate retrieval.
     * 2. Check local database cache for previously decrypted content (persists across restarts).
     * 3. Perform Signal Protocol decryption if the current user's payload is present.
     *
     * @param currentUserId The ID of the authenticated user attempting to read the message.
     * @return A copy of the [MessageDto] with decrypted content, or placeholder text if decryption fails.
     */
    suspend fun MessageDto.decryptIfNecessary(currentUserId: String): MessageDto {
        val messageId = this.id ?: return this

        return mutexFor(this.senderId).withLock {
            // 1) Check in-memory cache first (fastest)
            decryptedOrNull(messageId)?.let { cached ->
                Logger.d("E2EE_DECRYPT: Found message $messageId in memory cache", tag = "E2EE")
                val (content, mediaUrl, metadata) = extractContent(cached)
                return@withLock this.copy(content = content, mediaUrl = mediaUrl ?: this.mediaUrl, metadata = metadata ?: this.metadata)
            }

            // 2) Check local DB for previously-decrypted content (survives app restart)
            val dbCached = try {
                cachedMessageDao?.getMessageById(messageId)
            } catch (_: Exception) { null }
            if (dbCached != null &&
                dbCached.content.isNotBlank() &&
                !EncryptedPayloadDetector.isPlaceholder(dbCached.content) &&
                !EncryptedPayloadDetector.isEncryptedPayload(dbCached.content)
            ) {
                Logger.d("E2EE_DECRYPT: Found message $messageId in local DB cache", tag = "E2EE")
                cacheDecrypted(messageId, dbCached.content)
                return@withLock this.copy(content = dbCached.content, mediaUrl = dbCached.mediaUrl ?: this.mediaUrl, metadata = dbCached.metadataContainer?.let {
                    try { Json.encodeToString(com.synapse.social.studioasinc.shared.domain.model.chat.MessageMetadataContainer.serializer(), it) } catch (_: Exception) { null }
                } ?: this.metadata)
            }

            try {
                val looksLikeEncryptedPayload = EncryptedPayloadDetector.isEncryptedPayload(this.content)

                if (looksLikeEncryptedPayload) {
                    val jsonElement = Json.parseToJsonElement(this.content).jsonObject
                    val myPayloadElement = jsonElement[currentUserId]

                    // The sender's own entry is a plaintext JSON payload, not a ratchet message.
                    // Read it directly so the sending device (and its other devices) never show
                    // the raw envelope as message text.
                    if (myPayloadElement is JsonPrimitive && myPayloadElement.isString) {
                        val plaintextPayload = myPayloadElement.content
                        val (content, mediaUrl, metadata) = extractContent(plaintextPayload)
                        cacheDecrypted(messageId, plaintextPayload)
                        try { cachedMessageDao?.updateContent(messageId, content) } catch (_: Exception) {}
                        return@withLock this.copy(
                            content = content,
                            mediaUrl = mediaUrl ?: this.mediaUrl,
                            metadata = metadata ?: this.metadata,
                            encryptionFailureReason = null
                        )
                    }

                    if (signalProtocolManager != null && myPayloadElement != null) {
                        val senderId = this.senderId
                        val myPayload = Json.decodeFromJsonElement(EncryptedMessage.serializer(), myPayloadElement)
                        try {
                            // A PreKey envelope bootstraps the receiving session itself. Do NOT
                            // establish an outgoing session toward the sender (would consume the
                            // sender's pre-keys) and do NOT wipe an existing receiving session before
                            // attempting decryption. Only clear stale state on failure.
                            val decryptedBytes = signalProtocolManager.decryptMessage(senderId = senderId, message = myPayload)
                            val decryptedContent = decryptedBytes.decodeToString()
                            Logger.d("E2EE_DECRYPT: Successfully decrypted message $messageId", tag = "E2EE")
                            cacheDecrypted(messageId, decryptedContent)
                            val (content, mediaUrl, metadata) = extractContent(decryptedContent)
                            try { cachedMessageDao?.updateContent(messageId, content) } catch (_: Exception) {}
                            return@withLock this.copy(content = content, mediaUrl = mediaUrl ?: this.mediaUrl, metadata = metadata ?: this.metadata, encryptionFailureReason = null)
                        } catch (decryptError: Throwable) {
                            if (decryptError is CancellationException) throw decryptError
                            // A PreKey envelope can only be consumed once, and re-establishing an
                            // outgoing session toward the sender is exactly what corrupts bootstrap, so
                            // we do NOT retry the same payload here. Clear any stale session bound to a
                            // previous identity so the sender's *next* message opens a clean receiving
                            // session; the Double Ratchet recovers from there.
                            Logger.e("E2EE_DECRYPT: Signal decryption failed for message $messageId from $senderId. Clearing stale session so the next message can bootstrap cleanly.", tag = "E2EE", throwable = decryptError)
                            try { signalProtocolManager.deleteSession(senderId) } catch (_: Exception) {}
                        }
                    }
                    return@withLock this.copy(encryptionFailureReason = "decryption_failed")
                }
            } catch (_: Exception) {
                // Not an encrypted payload
            }
            if (EncryptedPayloadDetector.isEncryptedPayload(this.content)) {
                this.copy(encryptionFailureReason = "decryption_failed")
            } else {
                this.copy(encryptionFailureReason = null)
            }
        }
    }

    /**
     * Ensures that a Signal Protocol session exists for the specified [userId].
     * If no session exists, it fetches the user's public key bundle from the server
     * and establishes a new session.
     *
     * @param userId The ID of the user to establish a session with.
     * @throws Exception if the user has not enabled E2EE (no public keys found).
     */
    suspend fun ensureSession(userId: String) {
        if (signalProtocolManager != null && !signalProtocolManager.hasSession(userId)) {
            Logger.d("E2EE_SESSION: No session exists for user $userId, establishing...", tag = "E2EE")
            val keyDto = dataSource.getUserPublicKey(userId)
            if (keyDto != null) {
                Logger.d("E2EE_SESSION: Found public key for user $userId, processing bundle", tag = "E2EE")
                val bundle = Json.decodeFromString<PreKeyBundle>(keyDto.publicKey)
                signalProtocolManager.processPreKeyBundle(userId, bundle)
                Logger.d("E2EE_SESSION: Session established successfully for user $userId", tag = "E2EE")
            } else {
                Logger.e("E2EE_SESSION: Public key not found for user $userId. They probably haven't enabled E2EE.", tag = "E2EE")
                throw Exception("Recipient hasn't enabled E2EE")
            }
        } else if (signalProtocolManager != null) {
            Logger.d("E2EE_SESSION: Session already exists for user $userId", tag = "E2EE")
        }
    }

    /**
     * Initializes E2EE for the current user.
     *
     * This method handles several scenarios:
     * - Initial setup: Generates identity and pre-keys, and uploads the bundle to the server.
     * - Synchronization: Re-uploads the bundle if remote keys are missing but local keys exist.
     * - Conflict resolution: If the remote identity key doesn't match the local one (e.g., after a re-install),
     *   it clears old local sessions and re-uploads the new local bundle to the server.
     *
     * @param currentUserId The ID of the authenticated user.
     * @return A [Result] indicating success or failure of the initialization.
     */
    suspend fun initializeE2EE(currentUserId: String?): Result<Unit> {
        return try {
            if (signalProtocolManager == null) {
                val error = "SignalProtocolManager is null, E2EE not available"
                Logger.e("E2EE_INIT: $error", tag = "E2EE")
                return Result.failure(Exception(error))
            }

            if (currentUserId == null) {
                val error = "User not authenticated, cannot initialize E2EE"
                Logger.e("E2EE_INIT: $error", tag = "E2EE")
                return Result.failure(Exception(error))
            }

            Logger.d("E2EE_INIT: Starting E2EE initialization for user $currentUserId", tag = "E2EE")

            val hasLocalKeys = signalProtocolManager.hasIdentity()
            val remoteKeyDto = try { dataSource.getUserPublicKey(currentUserId) } catch (_: Exception) { null }
            val hasRemoteKeys = remoteKeyDto != null

            // Check if remote identity matches local identity
            var isIdentityMismatch = false
            if (hasLocalKeys && hasRemoteKeys && remoteKeyDto != null) {
                try {
                    val localIdentity = signalProtocolManager.getLocalIdentityKey()
                    val remoteBundle = Json.decodeFromString<PreKeyBundle>(remoteKeyDto.publicKey)
                    if (localIdentity != remoteBundle.identityKey) {
                        Logger.w("E2EE_INIT: Identity mismatch detected! Remote: ${remoteBundle.identityKey.take(10)}..., Local: ${localIdentity.take(10)}...", tag = "E2EE")
                        isIdentityMismatch = true
                    }
                } catch (e: Exception) {
                    Logger.e("E2EE_INIT: Failed to compare identities", tag = "E2EE", throwable = e)
                }
            }

            Logger.d("E2EE_INIT: hasLocalKeys=$hasLocalKeys, hasRemoteKeys=$hasRemoteKeys, mismatch=$isIdentityMismatch", tag = "E2EE")

            when {
                hasLocalKeys && hasRemoteKeys && !isIdentityMismatch -> {
                    // Both exist and match — fully initialized
                    val regId = signalProtocolManager.getLocalRegistrationId()
                    Logger.d("E2EE_INIT: E2EE already fully initialized (regId: $regId)", tag = "E2EE")

                    if (signalProtocolManager.checkKeyRotationNeeded()) {
                        Logger.w("E2EE_INIT: Key rotation recommended (keys older than 30 days)", tag = "E2EE")
                    }
                }
                hasLocalKeys && (!hasRemoteKeys || isIdentityMismatch) -> {
                    // Local keys exist but remote missing or mismatched — re-upload the bundle
                    if (isIdentityMismatch) {
                        Logger.w("E2EE_INIT: Identity mismatch — overwriting remote keys and clearing all sessions", tag = "E2EE")
                        // Clear all local sessions because they are tied to the old identity
                        signalProtocolManager.deleteAllSessions()
                    } else {
                        Logger.w("E2EE_INIT: Local keys exist but remote keys MISSING. Re-uploading...", tag = "E2EE")
                    }
                    val bundle = buildBundleFromLocalKeys()
                    val bundleStr = Json.encodeToString(bundle)
                    dataSource.uploadUserPublicKey(bundleStr)
                    Logger.d("E2EE_INIT: Successfully uploaded public key bundle", tag = "E2EE")
                }
                else -> {
                    // No local keys (or both missing) — full generation
                    if (!hasLocalKeys && hasRemoteKeys) {
                        Logger.w("E2EE_INIT: Remote keys exist but local keys MISSING. Regenerating everything...", tag = "E2EE")
                    } else {
                        Logger.d("E2EE_INIT: Fresh E2EE setup — no local or remote keys", tag = "E2EE")
                    }

                    val identity = signalProtocolManager.generateIdentityAndKeys()
                    Logger.d("E2EE_INIT: Generated identity with regId: ${identity.registrationId}", tag = "E2EE")

                    val preKeys = signalProtocolManager.generateOneTimePreKeys(startId = 1, count = 100)
                    Logger.d("E2EE_INIT: Generated ${preKeys.size} one-time pre-keys", tag = "E2EE")

                    val bundle = PreKeyBundle(
                        registrationId = identity.registrationId,
                        deviceId = 1,
                        preKeyId = null,
                        preKeyPublic = null,
                        signedPreKeyId = identity.signedPreKeyId,
                        signedPreKeyPublic = identity.signedPreKey,
                        signedPreKeySignature = identity.signedPreKeySignature,
                        identityKey = identity.identityKey
                    )

                    val bundleStr = Json.encodeToString(bundle)
                    Logger.d("E2EE_INIT: Uploading public key bundle to server", tag = "E2EE")
                    dataSource.uploadUserPublicKey(bundleStr)
                    Logger.d("E2EE_INIT: Successfully uploaded public key bundle", tag = "E2EE")
                }
            }

            Result.success(Unit)
        } catch (e: Exception) {
            Logger.e("E2EE_INIT: Initialization failed: ${e.message}", tag = "E2EE", throwable = e)
            Result.failure(e)
        }
    }

    /**
     * Builds a PreKeyBundle from the existing local keys.
     * Used when local keys exist but remote upload was missed.
     */
    private suspend fun buildBundleFromLocalKeys(): PreKeyBundle {
        val regId = signalProtocolManager!!.getLocalRegistrationId()
        val identityKey = signalProtocolManager.getLocalIdentityKey()

        // Generate fresh pre-keys to attach to the bundle
        val preKeys = signalProtocolManager.generateOneTimePreKeys(startId = 1, count = 100)

        // We need a signed pre-key — regenerate keys to also get the signed pre-key info
        // Since the identity already exists, generateIdentityAndKeys() will re-create from the same pair
        val identity = signalProtocolManager.generateIdentityAndKeys()

        return PreKeyBundle(
            registrationId = regId,
            deviceId = 1,
            preKeyId = null,
            preKeyPublic = null,
            signedPreKeyId = identity.signedPreKeyId,
            signedPreKeyPublic = identity.signedPreKey,
            signedPreKeySignature = identity.signedPreKeySignature,
            identityKey = identity.identityKey
        )
    }
}
