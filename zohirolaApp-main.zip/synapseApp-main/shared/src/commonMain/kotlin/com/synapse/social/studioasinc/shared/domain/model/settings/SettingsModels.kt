package com.synapse.social.studioasinc.shared.domain.model.settings

enum class ThemeMode { LIGHT, DARK, SYSTEM }

enum class FontScale {
    SMALL, MEDIUM, LARGE, EXTRA_LARGE;
    fun displayName(): String = name.lowercase().replaceFirstChar { it.uppercase() }
}

enum class PostViewStyle {
    SWIPE, GRID;
    fun displayName(): String = name.lowercase().replaceFirstChar { it.uppercase() }
}

enum class ProfileVisibility {
    PUBLIC, FOLLOWERS_ONLY, PRIVATE;
    fun displayName(): String = name.lowercase().replace("_", " ").replaceFirstChar { it.uppercase() }
}

enum class ContentVisibility {
    EVERYONE, FOLLOWERS, ONLY_ME;
    fun displayName(): String = name.lowercase().replace("_", " ").replaceFirstChar { it.uppercase() }
}

enum class GroupPrivacy {
    EVERYONE, MY_CONTACTS, MY_CONTACTS_EXCEPT, NOBODY;
    fun displayName(): String = name.lowercase().replace("_", " ").replaceFirstChar { it.uppercase() }
}

enum class LastSeenVisibility {
    EVERYONE, MY_CONTACTS, MY_CONTACTS_EXCEPT, NOBODY;
    fun displayName(): String = name.lowercase().replace("_", " ").replaceFirstChar { it.uppercase() }
}

enum class ProfilePhotoVisibility {
    EVERYONE, MY_CONTACTS, MY_CONTACTS_EXCEPT, NOBODY;
    fun displayName(): String = name.lowercase().replace("_", " ").replaceFirstChar { it.uppercase() }
}

enum class AboutVisibility {
    EVERYONE, MY_CONTACTS, MY_CONTACTS_EXCEPT, NOBODY;
    fun displayName(): String = name.lowercase().replace("_", " ").replaceFirstChar { it.uppercase() }
}

enum class StatusVisibility {
    EVERYONE, MY_CONTACTS, MY_CONTACTS_EXCEPT, NOBODY;
    fun displayName(): String = name.lowercase().replace("_", " ").replaceFirstChar { it.uppercase() }
}

enum class NotificationCategory {
    LIKES, COMMENTS, REPLIES, FOLLOWS, MESSAGES, MENTIONS, NEW_POSTS, SHARES, SYSTEM_UPDATES;
    fun displayName(): String = name.lowercase().replace("_", " ").replaceFirstChar { it.uppercase() }
}

enum class MediaAutoDownload {
    ALWAYS, WIFI_ONLY, NEVER;
    fun displayName(): String = name.lowercase().replace("_", " ").replaceFirstChar { it.uppercase() }
}

enum class MediaUploadQuality {
    STANDARD, HD;
    fun displayName(): String = when (this) {
        STANDARD -> "Standard Quality"
        HD -> "HD Quality"
    }
}

enum class MediaType {
    PHOTO, AUDIO, VIDEO, DOCUMENT, OTHER;
    fun displayName(): String = name.lowercase().replaceFirstChar { it.uppercase() }
}

data class AutoDownloadRules(
    val mobileData: Set<MediaType> = setOf(MediaType.PHOTO),
    val wifi: Set<MediaType> = MediaType.values().toSet(),
    val roaming: Set<MediaType> = emptySet()
)

data class StorageUsageBreakdown(
    val totalSize: Long,
    val usedSize: Long,
    val freeSize: Long,
    val appsAndOtherSize: Long,
    val synapseSize: Long,
    val photoSize: Long = 0L,
    val videoSize: Long = 0L,
    val documentSize: Long = 0L,
    val otherSize: Long = 0L,
    val chatSize: Long = 0L
)

data class LargeFileInfo(
    val fileId: String,
    val fileName: String,
    val size: Long,
    val thumbnailUri: String?,
    val type: MediaType
)

data class AppearanceSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val dynamicColorEnabled: Boolean = true,
    val fontScale: FontScale = FontScale.MEDIUM,
    val postViewStyle: PostViewStyle = PostViewStyle.SWIPE
)

data class PrivacySettings(
    val profileVisibility: ProfileVisibility = ProfileVisibility.PUBLIC,
    val twoFactorEnabled: Boolean = false,
    val biometricLockEnabled: Boolean = false,
    val contentVisibility: ContentVisibility = ContentVisibility.EVERYONE,
    val groupPrivacy: GroupPrivacy = GroupPrivacy.EVERYONE,
    val readReceiptsEnabled: Boolean = true,
    val appLockEnabled: Boolean = false,
    val chatLockEnabled: Boolean = false,
    val lastSeenVisibility: LastSeenVisibility = LastSeenVisibility.EVERYONE,
    val profilePhotoVisibility: ProfilePhotoVisibility = ProfilePhotoVisibility.EVERYONE,
    val aboutVisibility: AboutVisibility = AboutVisibility.EVERYONE,
    val statusVisibility: StatusVisibility = StatusVisibility.EVERYONE,
    val lastSeenExcludedUserIds: Set<String> = emptySet(),
    val profilePhotoExcludedUserIds: Set<String> = emptySet(),
    val aboutExcludedUserIds: Set<String> = emptySet(),
    val statusExcludedUserIds: Set<String> = emptySet(),
    val groupExcludedUserIds: Set<String> = emptySet()
)

data class NotificationPreferences(
    val globalEnabled: Boolean = true,
    val likesEnabled: Boolean = true,
    val commentsEnabled: Boolean = true,
    val repliesEnabled: Boolean = true,
    val followsEnabled: Boolean = true,
    val mentionsEnabled: Boolean = true,
    val newPostsEnabled: Boolean = true,
    val sharesEnabled: Boolean = true,
    val securityEnabled: Boolean = true,
    val updatesEnabled: Boolean = true,
    val quietHoursEnabled: Boolean = false,
    val quietHoursStart: String = "22:00",
    val quietHoursEnd: String = "08:00",
    val doNotDisturb: Boolean = false,
    val dndUntil: String? = null,
    val inAppNotificationsEnabled: Boolean = true,
    val remindersEnabled: Boolean = false,
    val highPriorityEnabled: Boolean = true,
    val reactionNotificationsEnabled: Boolean = true,
    val messagesEnabled: Boolean = true
) {
    fun isEnabled(category: NotificationCategory): Boolean = when (category) {
        NotificationCategory.LIKES -> likesEnabled
        NotificationCategory.COMMENTS -> commentsEnabled
        NotificationCategory.REPLIES -> repliesEnabled
        NotificationCategory.FOLLOWS -> followsEnabled
        NotificationCategory.MESSAGES -> messagesEnabled
        NotificationCategory.MENTIONS -> mentionsEnabled
        NotificationCategory.NEW_POSTS -> newPostsEnabled
        NotificationCategory.SHARES -> sharesEnabled
        NotificationCategory.SYSTEM_UPDATES -> updatesEnabled
    }

    fun withCategory(category: NotificationCategory, enabled: Boolean): NotificationPreferences = when (category) {
        NotificationCategory.LIKES -> copy(likesEnabled = enabled)
        NotificationCategory.COMMENTS -> copy(commentsEnabled = enabled)
        NotificationCategory.REPLIES -> copy(repliesEnabled = enabled)
        NotificationCategory.FOLLOWS -> copy(followsEnabled = enabled)
        NotificationCategory.MESSAGES -> copy(messagesEnabled = enabled)
        NotificationCategory.MENTIONS -> copy(mentionsEnabled = enabled)
        NotificationCategory.NEW_POSTS -> copy(newPostsEnabled = enabled)
        NotificationCategory.SHARES -> copy(sharesEnabled = enabled)
        NotificationCategory.SYSTEM_UPDATES -> copy(updatesEnabled = enabled)
    }
}
