package com.synapse.social.studioasinc.shared.data.crypto

import android.content.Context
import android.util.Base64
import com.synapse.social.studioasinc.shared.data.crypto.models.EncryptedMessage
import com.synapse.social.studioasinc.shared.data.crypto.models.PreKeyBundle
import com.synapse.social.studioasinc.shared.data.crypto.models.SignalIdentityKeys
import com.synapse.social.studioasinc.shared.data.crypto.models.SignalOneTimePreKey
import com.synapse.social.studioasinc.shared.data.crypto.store.AndroidSignalStore
import com.synapse.social.studioasinc.shared.util.Logger
import kotlinx.coroutines.CancellationException

// ── libsignal-android (org.signal:libsignal-android) ─────────────────────────
// Replaces the archived org.whispersystems:signal-protocol-android:2.8.x.
// Package root changed from org.whispersystems.libsignal.* → org.signal.libsignal.protocol.*
// All method signatures and the Signal wire format are identical.
import org.signal.libsignal.protocol.IdentityKey
import org.signal.libsignal.protocol.IdentityKeyPair
import org.signal.libsignal.protocol.SessionBuilder
import org.signal.libsignal.protocol.SessionCipher
import org.signal.libsignal.protocol.SignalProtocolAddress
import org.signal.libsignal.protocol.message.CiphertextMessage
import org.signal.libsignal.protocol.message.PreKeySignalMessage
import org.signal.libsignal.protocol.message.SignalMessage
import org.signal.libsignal.protocol.state.PreKeyRecord
import org.signal.libsignal.protocol.state.SignedPreKeyRecord
import org.signal.libsignal.protocol.util.KeyHelper
import org.signal.libsignal.protocol.state.PreKeyBundle as SignalNativePreKeyBundle

class AndroidSignalProtocolManager(context: Context) : SignalProtocolManager {

    private val store = AndroidSignalStore(context)
    private val DEVICE_ID = 1

    override suspend fun generateIdentityAndKeys(): SignalIdentityKeys {
        val identityKeyPair: IdentityKeyPair
        val registrationId: Int

        if (store.hasIdentity()) {
            // Reuse existing identity — only refresh the signed pre-key
            Logger.d("E2EE_INIT: Reusing existing identity key pair", tag = "E2EE")
            identityKeyPair = store.identityKeyPair
            registrationId = store.getLocalRegistrationId()
        } else {
            // Fresh generation using libsignal API
            Logger.d("E2EE_INIT: Generating new identity key pair", tag = "E2EE")
            identityKeyPair = IdentityKeyPair.generate()
            registrationId = KeyHelper.generateRegistrationId(false)
            store.storeLocalIdentity(identityKeyPair, registrationId)
        }

        // Generate a signed pre-key. Using an ID derived from current time to avoid overwriting
        // issues while staying within the expected Int range for Signal protocols.
        val signedPreKeyId = (System.currentTimeMillis() / 1000 % 0x00FFFFFF).toInt()
        val signedPreKeyPair = org.signal.libsignal.protocol.ecc.Curve.generateKeyPair()
        val signedPreKeySignature = identityKeyPair.privateKey.calculateSignature(signedPreKeyPair.publicKey.serialize())
        val signedPreKey = SignedPreKeyRecord(
            signedPreKeyId,
            System.currentTimeMillis(),
            signedPreKeyPair,
            signedPreKeySignature
        )
        store.storeSignedPreKey(signedPreKey.id, signedPreKey)
        Logger.d(
            "E2EE_INIT: Stored identity and signed pre-key locally (regId: $registrationId, signedKeyId: $signedPreKeyId)",
            tag = "E2EE"
        )

        return SignalIdentityKeys(
            registrationId = registrationId,
            identityKey = Base64.encodeToString(identityKeyPair.publicKey.serialize(), Base64.NO_WRAP),
            signedPreKeyId = signedPreKey.id,
            signedPreKey = Base64.encodeToString(signedPreKey.keyPair.publicKey.serialize(), Base64.NO_WRAP),
            signedPreKeySignature = Base64.encodeToString(signedPreKey.signature, Base64.NO_WRAP)
        )
    }

    override suspend fun generateOneTimePreKeys(startId: Int, count: Int): List<SignalOneTimePreKey> {
        Logger.d("E2EE_INIT: Generating $count one-time pre-keys starting from ID $startId", tag = "E2EE")
        val resultList = mutableListOf<SignalOneTimePreKey>()
        for (i in 0 until count) {
            val keyId = (startId + i) % 0xFFFFFF
            val keyPair = org.signal.libsignal.protocol.ecc.Curve.generateKeyPair()
            val preKey = PreKeyRecord(keyId, keyPair)
            store.storePreKey(preKey.id, preKey)
            resultList.add(
                SignalOneTimePreKey(
                    keyId = preKey.id,
                    publicKey = Base64.encodeToString(preKey.keyPair.publicKey.serialize(), Base64.NO_WRAP)
                )
            )
        }
        return resultList
    }

    override suspend fun processPreKeyBundle(userId: String, bundle: PreKeyBundle) {
        Logger.d("E2EE_SESSION: Processing pre-key bundle for user $userId", tag = "E2EE")
        val address = SignalProtocolAddress(userId, DEVICE_ID)
        val sessionBuilder = SessionBuilder(store, address)

        // Note: new libsignal IdentityKey constructor takes only the byte array (no offset).
        val nativeBundle = SignalNativePreKeyBundle(
            bundle.registrationId,
            bundle.deviceId,
            bundle.preKeyId ?: -1,
            bundle.preKeyPublic?.let {
                org.signal.libsignal.protocol.ecc.Curve.decodePoint(Base64.decode(it, Base64.DEFAULT), 0)
            },
            bundle.signedPreKeyId,
            org.signal.libsignal.protocol.ecc.Curve.decodePoint(
                Base64.decode(bundle.signedPreKeyPublic, Base64.DEFAULT), 0
            ),
            Base64.decode(bundle.signedPreKeySignature, Base64.DEFAULT),
            IdentityKey(Base64.decode(bundle.identityKey, Base64.DEFAULT))
        )

        sessionBuilder.process(nativeBundle)
        Logger.d("E2EE_SESSION: Successfully processed bundle and established session for $userId", tag = "E2EE")
    }

    override suspend fun hasSession(userId: String): Boolean {
        val address = SignalProtocolAddress(userId, DEVICE_ID)
        return store.containsSession(address)
    }

    override suspend fun deleteSession(userId: String) {
        Logger.d("E2EE_SESSION: Deleting session for user $userId", tag = "E2EE")
        val address = SignalProtocolAddress(userId, DEVICE_ID)
        store.deleteSession(address)
        Logger.d("E2EE_SESSION: Session deleted for user $userId", tag = "E2EE")
    }

    override suspend fun deleteAllSessions() {
        Logger.d("E2EE_SESSION: Deleting all sessions", tag = "E2EE")
        store.deleteAllSessions(null)
        Logger.d("E2EE_SESSION: All sessions deleted", tag = "E2EE")
    }

    override suspend fun deleteIdentity(userId: String) {
        Logger.d("E2EE_SESSION: Deleting identity for user $userId", tag = "E2EE")
        val address = SignalProtocolAddress(userId, DEVICE_ID)
        store.deleteIdentity(address)
        Logger.d("E2EE_SESSION: Identity deleted for user $userId", tag = "E2EE")
    }

    override suspend fun encryptMessage(recipientId: String, message: ByteArray): EncryptedMessage {
        Logger.d("E2EE_ENCRYPT: Encrypting message for recipient $recipientId", tag = "E2EE")
        val address = SignalProtocolAddress(recipientId, DEVICE_ID)
        val sessionCipher = SessionCipher(store, address)
        val ciphertextMessage = sessionCipher.encrypt(message)
        Logger.d("E2EE_ENCRYPT: Successfully encrypted message (type: ${ciphertextMessage.type})", tag = "E2EE")

        return EncryptedMessage(
            type = ciphertextMessage.type,
            body = Base64.encodeToString(ciphertextMessage.serialize(), Base64.NO_WRAP),
            registrationId = store.getLocalRegistrationId()
        )
    }

    override suspend fun decryptMessage(senderId: String, message: EncryptedMessage): ByteArray {
        Logger.d("E2EE_DECRYPT: Decrypting message from sender $senderId (type: ${message.type})", tag = "E2EE")
        val address = SignalProtocolAddress(senderId, DEVICE_ID)
        val sessionCipher = SessionCipher(store, address)

        val decodedBody = Base64.decode(message.body, Base64.DEFAULT)

        val decrypted = if (message.type == CiphertextMessage.PREKEY_TYPE) {
            // A PreKey envelope bootstraps the receiving session itself. Its serialized bytes
            // include the PreKey header, so they are NOT a valid plain SignalMessage — parsing
            // them as one (the previous "fallback when a session exists") always threw and, worse,
            // re-processed a single-use envelope while masking the true root cause. Hand the
            // envelope to libsignal once and surface the real exception on failure.
            try {
                sessionCipher.decrypt(PreKeySignalMessage(decodedBody))
            } catch (e: Throwable) {
                if (e is CancellationException) throw e
                Logger.e(
                    "E2EE_DECRYPT: PreKey decrypt failed for sender $senderId (${e.javaClass.simpleName}: ${e.message})",
                    tag = "E2EE",
                    throwable = e
                )
                throw e
            }
        } else {
            sessionCipher.decrypt(SignalMessage(decodedBody))
        }
        Logger.d("E2EE_DECRYPT: Successfully decrypted message from $senderId", tag = "E2EE")
        return decrypted
    }

    override suspend fun getLocalRegistrationId(): Int {
        return store.getLocalRegistrationId()
    }

    override suspend fun getLocalIdentityKey(): String {
        return Base64.encodeToString(store.identityKeyPair.publicKey.serialize(), Base64.NO_WRAP)
    }

    override suspend fun checkKeyRotationNeeded(thresholdDays: Int): Boolean {
        return store.checkKeyRotationNeeded(thresholdDays)
    }

    override suspend fun hasIdentity(): Boolean {
        return store.hasIdentity()
    }
}
